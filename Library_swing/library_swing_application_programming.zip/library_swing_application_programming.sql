-- phpMyAdmin SQL Dump
-- version 4.8.5
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: May 29, 2021 at 05:29 PM
-- Server version: 10.1.38-MariaDB
-- PHP Version: 7.3.2

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `library_swing_application_programming`
--

-- --------------------------------------------------------

--
-- Table structure for table `books`
--

CREATE TABLE `books` (
  `id` int(11) NOT NULL,
  `name` varchar(100) DEFAULT NULL,
  `author` varchar(100) DEFAULT NULL,
  `department` varchar(100) DEFAULT NULL,
  `page_number` int(11) DEFAULT NULL,
  `route` varchar(200) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `books`
--

INSERT INTO `books` (`id`, `name`, `author`, `department`, `page_number`, `route`) VALUES
(1, 'OOP', 'Bamo Nadir', 'Computer', 3242, 'C:\\Users\\Hastyar\\Downloads\\_____all_of_me_-_john_legend.pdf'),
(2, 'AI', 'jaza', 'Computer', 3221, 'C:\\Users\\Hastyar\\Downloads\\bluman_statistics_book.pdf'),
(3, 'Database Systems', 'Hakar Ali', 'Computer', 1223, 'C:\\Users\\Hastyar\\Downloads\\Dr. Joe Dispenza - Becoming Supernatural_ How Common People Are Doing the Uncommon-Hay House (2017).pdf'),
(4, 'java software solutions', 'Hastyar', 'Computer', 3984, 'books/Computer/Joe Dispenza - Breaking the Habit of Being Yourself_ How to Lose Your Mind and Create a New One-Hay House (2012).pdf'),
(5, 'accounting principles', 'harzhin', 'Business', 2341, 'books/Business/scan;sadlkfj;asldkfjs;adlkfj;l.pdf'),
(6, 'test book', 'test', 'Environment', 87878, 'books/Environment/KUST Attendance System info-graphy.pdf');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `name` varchar(100) DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  `address` varchar(100) DEFAULT NULL,
  `code` int(11) DEFAULT NULL,
  `username` varchar(100) DEFAULT NULL,
  `password` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `email`, `address`, `code`, `username`, `password`) VALUES
(1, 'hastyar', 'hastyar.azadf17@komar.edu.iq', 'sulaimani/chwarchra', 170001, 'hastyar', 'Hastyar123');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `books`
--
ALTER TABLE `books`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `books`
--
ALTER TABLE `books`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
